# frozen_string_literal: true

module BookstoresHelper
end
