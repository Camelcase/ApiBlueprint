# frozen_string_literal: true

module BooksHelper
end
