# frozen_string_literal: true

module V2
  module BooksHelper
  end
end
