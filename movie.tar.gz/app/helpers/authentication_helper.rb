# frozen_string_literal: true

module AuthenticationHelper
end
